import React, { useRef, useState, useEffect } from 'react';
import styles from '../styles/TopBar.module.css';

const tabs = [
  'Billing Overview',
  'Insurance Provider Insights',
  'Delay Duration Categories',
  'Delay Reason Breakdown',
  'Insurance & Delay Reason Summary',
];

const TopBar = ({ activeTab = 0, onTabChange }) => {
  const tabBarRef = useRef(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const checkScroll = () => {
    const el = tabBarRef.current;
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 0);
    setCanScrollRight(el.scrollLeft + el.clientWidth < el.scrollWidth - 1);
  };

  useEffect(() => {
    checkScroll();
    const el = tabBarRef.current;
    if (!el) return;
    el.addEventListener('scroll', checkScroll);
    window.addEventListener('resize', checkScroll);
    return () => {
      el.removeEventListener('scroll', checkScroll);
      window.removeEventListener('resize', checkScroll);
    };
  }, []);

  const scrollTabs = (dir) => {
    const el = tabBarRef.current;
    if (!el) return;
    const amount = el.clientWidth * 0.6;
    el.scrollBy({ left: dir * amount, behavior: 'smooth' });
  };

  return (
    <div className={`${styles.topBarWrapper} ${styles.fixedTopBar}`}>
      <div className={styles.dashboardTitle}>
        CLAIMS DELAYS INSIGHTS DASHBOARD
      </div>
      <div className={styles.tabBarOuter}>
        {canScrollLeft && (
          <button className={`${styles.tabArrow} ${styles.tabArrowLeft}`} onClick={() => scrollTabs(-1)} aria-label="Scroll left">
            &#8249;
          </button>
        )}
        <div className={styles.tabBar} ref={tabBarRef}>
          {tabs.map((tab, idx) => (
            <button
              key={tab}
              onClick={() => onTabChange && onTabChange(idx)}
              className={
                activeTab === idx
                  ? `${styles.tabButton} ${styles.active}`
                  : styles.tabButton
              }
            >
              {tab}
            </button>
          ))}
        </div>
        {canScrollRight && (
          <button className={`${styles.tabArrow} ${styles.tabArrowRight}`} onClick={() => scrollTabs(1)} aria-label="Scroll right">
            &#8250;
          </button>
        )}
      </div>
    </div>
  );
};

export default TopBar; 