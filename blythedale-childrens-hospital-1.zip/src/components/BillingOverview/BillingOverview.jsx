import React, { useState, useEffect } from 'react';
import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import styles from '../../styles/BillingOverview.module.css';
import axios from 'axios';
import Select from 'react-select';
import PrimeDataTable from '../common/PrimeDataTable';
import CommonPieChart, { CommonPieLegend } from '../common/CommonPieChart';
import { getLightAndStrongColorByIndex } from '../../utility/colorUtils';

const BillingOverview = () => {
  const [view, setView] = useState('table');
  const [rowData, setRowData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedStatuses, setSelectedStatuses] = useState([]);
  const [metricGroups, setMetricGroups] = useState([]);
  const statusOptions = [
    { value: 'Posted', label: 'Posted' },
    { value: 'Reversed', label: 'Reversed' },
    { value: 'Cancelled', label: 'Cancelled' },
  ];

  const fetchData = async (statuses) => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get('/api/payment-status-summary');
      let data = response.data;
      if (statuses.length > 0) {
        const statusValues = statuses.map(s => s.value);
        data = data.filter(row => statusValues.includes(row.bill_status));
      }
      setRowData(data);
    } catch (err) {
      setError('Failed to load table data.');
    } finally {
      setLoading(false);
    }
  };

  const fetchMetricsData = async () => {
    try {
      const response = await axios.get('/api/overall-billing-metrics');
      if (response.data && Array.isArray(response.data)) {
        setMetricGroups(response.data);
      } else {
        setMetricGroups([]);
      }
    } catch (err) {
      setMetricGroups([]);
    }
  };

  // Fetch data on mount and when filter changes
  useEffect(() => {
    fetchData(selectedStatuses);
    fetchMetricsData();
  }, [selectedStatuses]);

  const handleClearFilters = () => setSelectedStatuses([]);

  // No frontend filtering, just use rowData
  const filteredData = rowData;

  // Map type to style classes
  const typeToCardClass = {
    patients: styles.cardBlue,
    accounts: styles.cardPurple,
    processed: styles.cardRed,
    posted: styles.cardYellow,
    reversed: styles.cardGreen,
  };
  const typeToValueClass = {
    patients: styles.metricValueBlue,
    accounts: styles.metricValuePurple,
    processed: styles.metricValueRed,
    posted: styles.metricValueYellow,
    reversed: styles.metricValueGreen,
  };

  const columns = [
    { field: 'status', header: 'Payment Status' },
    { field: 'bills', header: 'Number of Bills' },
    { field: 'amount', header: 'Total Amount' },
  ];

  return (
    <div className={styles.mainContainerWithTopMargin}>
      {/* Metric Cards */}
      {Array.isArray(metricGroups) && metricGroups[0]?.metrics && metricGroups[1]?.metrics ? (
        <div className="row g-2 mb-4">
          {/* Key Billing Metrics */}
          <div className="col-12 col-lg-7">
            <div className="card h-100">
              <div className="card-body">
                <div className={styles.metricsTitle}>Key Billing Metrics</div>
                <div className="row g-2">
                  {(() => {
                    const metrics = metricGroups[0].metrics;
                    return metrics.map((metric, idx) => {
                      if (idx < 3) {
                        return (
                          <div className="col-12 col-md-4" key={idx}>
                            <div className={`card border-0 shadow-sm ${typeToCardClass[metric.type]} ${styles.metricCard}`}> 
                              <div className="card-body d-flex flex-column justify-content-center align-items-center p-1" style={{height:'100%'}}>
                                <span
                                  className={styles.metricLabel}
                                  style={{ textAlign: 'center', width: '100%' }}
                                  dangerouslySetInnerHTML={{ __html: metric.label }}
                                />
                                <span className={typeToValueClass[metric.type]} style={{ display: 'block', textWrap: 'wrap' }}>{metric.value}</span>
                              </div>
                            </div>
                          </div>
                        );
                      } else {
                        // Use generated light/strong color for background and value text
                        const { light, strong } = getLightAndStrongColorByIndex(idx, metrics.length);
                        return (
                          <div className="col-12 col-md-4" key={idx}>
                            <div className={`card border-0 shadow-sm ${styles.metricCard}`} style={{ background: light }}>
                              <div className="card-body d-flex flex-column justify-content-center align-items-center p-1" style={{height:'100%'}}>
                                <span
                                  className={styles.metricLabel}
                                  style={{ textAlign: 'center', width: '100%' }}
                                  dangerouslySetInnerHTML={{ __html: metric.label }}
                                />
                                <span style={{
                                  display: 'block',
                                  color: strong,
                                  fontWeight: 600,
                                  fontSize: '40px',
                                  textAlign: 'center',
                                  width: '100%',
                                  textWrap: 'wrap'
                                }}>{metric.value}</span>
                              </div>
                            </div>
                          </div>
                        );
                      }
                    });
                  })()}
                </div>
              </div>
            </div>
          </div>
          {/* Duration Based Billing Summary */}
          <div className="col-12 col-lg-5">
            <div className="card h-100">
              <div className="card-body">
                <div className={styles.metricsTitle}>Duration Based Billing Summary</div>
                <div className="row g-2">
                  {(() => {
                    const metrics = metricGroups[1].metrics;
                    return metrics.map((metric, idx) => {
                      if (idx < 2) {
                        return (
                          <div className="col-12 col-md-6" key={idx}>
                            <div className={`card border-0 shadow-sm ${typeToCardClass[metric.type]} ${styles.metricCard}`}> 
                              <div className="card-body d-flex flex-column justify-content-center align-items-center p-1" style={{height:'100%'}}>
                                <span
                                  className={styles.metricLabel}
                                  style={{ textAlign: 'center', width: '100%' }}
                                  dangerouslySetInnerHTML={{ __html: metric.label }}
                                />
                                <span className={typeToValueClass[metric.type]} style={{ display: 'block', textWrap: 'wrap' }}>{metric.value}</span>
                              </div>
                            </div>
                          </div>
                        );
                      } else {
                        // Use generated light/strong color for background and value text
                        const { light, strong } = getLightAndStrongColorByIndex(idx, metrics.length);
                        return (
                          <div className="col-12 col-md-6" key={idx}>
                            <div className={`card border-0 shadow-sm ${styles.metricCard}`} style={{ background: light }}>
                              <div className="card-body d-flex flex-column justify-content-center align-items-center p-1" style={{height:'100%'}}>
                                <span
                                  className={styles.metricLabel}
                                  style={{ textAlign: 'center', width: '100%' }}
                                  dangerouslySetInnerHTML={{ __html: metric.label }}
                                />
                                <span style={{
                                  display: 'block',
                                  color: strong,
                                  fontWeight: 600,
                                  fontSize: '40px',
                                  textAlign: 'center',
                                  width: '100%',
                                  textWrap: 'wrap'
                                }}>{metric.value}</span>
                              </div>
                            </div>
                          </div>
                        );
                      }
                    });
                  })()}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div></div>
      )}
      {/* Filter & Summary by Payment Status */}
      <div className={styles.summaryTitle}>Filter & Summary by Payment Status</div>
      <div className="card border-0 shadow-sm mb-4">
        <div className="card-body pb-0">
          <div className="row align-items-center">
            <div className="col d-flex align-items-center flex-wrap gap-2">
              {view === 'table' && (
                <>
                  <div style={{ minWidth: 300 }}>
                    <Select
                      isMulti
                      options={statusOptions}
                      value={selectedStatuses}
                      onChange={setSelectedStatuses}
                      placeholder="+ Select Bill Status"
                      classNamePrefix="select"
                      menuPortalTarget={document.body}
                      styles={{
                        menuPortal: base => ({ ...base, zIndex: 2000 }),
                      }}
                    />
                  </div>
                  <button
                    className="btn btn-outline-primary btn-sm ms-2"
                    style={{ whiteSpace: 'nowrap' }}
                    onClick={handleClearFilters}
                  >
                    Clear filters
                  </button>
                </>
              )}
            </div>
            <div className="col-auto">
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  className={view === 'table' ? `${styles.tabButton} ${styles.tabButtonActive}` : styles.tabButton}
                  onClick={() => setView('table')}
                  style={{ fontSize: '16px', fontFamily: 'inherit', fontWeight: 500 }}
                >
                  Table
                </button>
                <button
                  className={view === 'pie' ? `${styles.tabButton} ${styles.tabButtonActive}` : styles.tabButton}
                  onClick={() => setView('pie')}
                  style={{ fontSize: '16px', fontFamily: 'inherit', fontWeight: 500 }}
                >
                  Pie Chart
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="card-body">
          {loading ? (
            <div className="d-flex justify-content-center align-items-center" style={{ height: 200 }}>
              <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            </div>
          ) : error ? (
            <div style={{ color: '#b71c1c', background: '#fff3f3', padding: 16, borderRadius: 8, textAlign: 'center' }}>
              Sorry, we couldn't load your data right now. Please try again later.
            </div>
          ) : view === 'table' ? (
            <PrimeDataTable columns={columns} data={filteredData} loading={loading} error={error} />
          ) : (
            <CommonPieChart
              data={Array.isArray(filteredData) ? filteredData : []}
              dataKey="bills"
              nameKey="status"
              tooltipContent={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const d = payload[0]?.payload;
                  return (
                    <div style={{ padding: 12, background: '#fff', borderRadius: 14, boxShadow: '0 2px 12px #0001', fontWeight: 600, fontSize: 15 }}>
                      {d?.status} : {d?.bills}
                    </div>
                  );
                }
                return null;
              }}
              renderLegend={(data, colors, activeIndex, setActiveIndex) =>
                CommonPieLegend(data, colors, activeIndex, setActiveIndex, {
                  labelField: 'status',
                  valueField: 'amount',
                  subValueField: 'bills',
                  valueFormatter: v => v,
                  subValueFormatter: v => `No of Bills: ${v}`
                })
              }
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default BillingOverview; 