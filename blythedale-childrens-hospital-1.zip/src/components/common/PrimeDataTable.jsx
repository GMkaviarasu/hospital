import React from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import styles from '../../styles/PrimeDataTable.module.css';

const customPaginatorTemplate = {
    'RowsPerPageDropdown': (options) => {
        return (
            <span style={{ display: 'flex', alignItems: 'center', marginRight: 8 }}>
                <span style={{ marginRight: 4, color: '#6b7280', fontSize: '1rem' }}>Rows per page:</span>
                {options.element}
            </span>
        );
    },
    'CurrentPageReport': (options) => options.element,
    'PrevPageLink': (options) => options.element,
    'NextPageLink': (options) => options.element
};

const PrimeDataTable = ({ columns, data, loading, error, filter = {}, ...props }) => {
    if (loading) {
        return (
            <div className="d-flex justify-content-center align-items-center" style={{ height: 200 }}>
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </div>
        );
    }
    if (error) {
        return <div className="text-center text-danger" style={{ padding: 40 }}>{error}</div>;
    }

    // Ensure data is always an array
    const safeData = Array.isArray(data) ? data : [];
    
    // Ensure columns is always an array
    const safeColumns = Array.isArray(columns) ? columns : [];

    // Filtering logic
    let filteredData = safeData;
    if (filter && Object.keys(filter).length > 0) {
        filteredData = safeData.filter(row =>
            Object.entries(filter).every(([field, value]) =>
                value === '' ||
                (row[field] && String(row[field]).toLowerCase() === String(value).toLowerCase())
            )
        );
    }

    return (
        <div className={styles.dataTableWrapper}>
            <DataTable
                value={filteredData}
                paginator
                rows={10}
                rowsPerPageOptions={[10, 15, 20]}
                paginatorTemplate={customPaginatorTemplate}
                currentPageReportTemplate="{first}-{last} of {totalRecords}"
                paginatorClassName={styles.customPaginator}
                paginatorDropdownAppendTo="self"
                showGridlines
                scrollable
                scrollHeight="400px"
                className={styles.dataTable}
                emptyMessage="No records available"
                {...props}
            >
                {safeColumns.map(col => (
                    <Column key={col.field} field={col.field} header={col.header} sortable />
                ))}
            </DataTable>
        </div>
    );
};

export default PrimeDataTable; 