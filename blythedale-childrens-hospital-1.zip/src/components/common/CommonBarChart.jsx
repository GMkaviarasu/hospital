import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LabelList,
  Cell,
  Label,
} from 'recharts';
import styles from '../../styles/CommonBarTooltip.module.css';
import { generateColors } from '../../utility/colorUtils';

const CommonBarTooltip = ({ title = '', label1 = 'Count', value1, label2 = 'Label', value2 }) => {
  return (
    <div className={styles.tooltipBox}>
      {title && <div className={styles.tooltipTitle}>{title}</div>}
      <div className={styles.tooltipLine}>
        <span className={styles.tooltipLabel}>{label1}</span> : <span className={styles.tooltipValue}>{value1}</span>
      </div>
      <div className={styles.tooltipLine}>
        <span className={styles.tooltipLabel}>{label2}</span> : <span className={styles.tooltipValue}>{value2}</span>
      </div>
    </div>
  );
};

export function getBarTooltip({ titleFn, label1, value1Fn, label2, value2Fn }) {
  return function TooltipContent({ active, payload }) {
    if (active && payload && payload.length) {
      const d = payload[0].payload;
      return (
        <CommonBarTooltip
          title={titleFn ? titleFn(d) : ''}
          label1={label1}
          value1={value1Fn ? value1Fn(d) : ''}
          label2={label2}
          value2={value2Fn ? value2Fn(d) : ''}
        />
      );
    }
    return null;
  };
}

const CommonBarChart = ({
  data,
  xAxisKey = 'category',
  yAxisKey = 'count',
  labelFormatter,
  barSize = 80,
  yAxisTicks,
  yAxisDomain,
  xAxisProps = {},
  yAxisProps = {},
  valueLabel,
  yAxisLabel,
  title,
  tooltipContent,
}) => {
  const containerRef = React.useRef(null);
  const [containerWidth, setContainerWidth] = React.useState(900);

  React.useEffect(() => {
    const updateWidth = () => {
      if (containerRef.current) {
        setContainerWidth(containerRef.current.offsetWidth);
      }
    };
    updateWidth();
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, []);

  if (!Array.isArray(data) || data.length === 0) {
    return <div style={{ width: '100%', textAlign: 'center', color: '#888', padding: '2rem' }}>No data available</div>;
  }

  const coloredData = data.every(item => item.color)
    ? data
    : data.map((item, idx) => ({ ...item, color: generateColors(data.length)[idx] }));

    const WrappedXAxisTick = ({ x, y, payload }) => {
      const label = String(payload.value || 'N/A');
    
      // Estimate max chars per line based on chart width
      const chartWidth = containerWidth > 0 ? containerWidth * 0.95 : 900;
      const barCount = data.length || 5;
      const maxCharsPerLine = Math.floor((chartWidth / barCount) / 8); // 8px per char approximation
    
      const words = label.split(' ');
      const lines = [];
      let currentLine = '';
    
      words.forEach(word => {
        if ((currentLine + ' ' + word).trim().length > maxCharsPerLine && currentLine) {
          lines.push(currentLine);
          currentLine = word;
        } else {
          currentLine += (currentLine ? ' ' : '') + word;
        }
      });
      if (currentLine) lines.push(currentLine);
    
      return (
        <g transform={`translate(${x},${y + 8})`}>
          <text textAnchor="middle" fontSize={14} fill="#666">
            {lines.map((line, idx) => (
              <tspan x="0" dy={idx === 0 ? 0 : 15} key={idx}>{line}</tspan>
            ))}
          </text>
        </g>
      );
    };    

  return (
    <div className={styles.barChartScrollContainer}>
      <div className={styles.barChartInnerContainer} ref={containerRef}>
        <div className={styles.barChartTitle}>{title}</div>
        <ResponsiveContainer width="95%" height={420}>
          <BarChart data={coloredData} margin={{ top: 24, right: 32, left: 40, bottom: 70 }}>
            <XAxis
              dataKey={xAxisKey}
              tickLine={false}
              interval={0}
              tick={<WrappedXAxisTick />}
              {...xAxisProps}
            />
            <YAxis
              tick={{ fontSize: 14 }}
              ticks={yAxisTicks}
              domain={yAxisDomain}
              tickLine={false}
              {...yAxisProps}
            >
              <Label
                value={yAxisLabel}
                angle={-90}
                position="insideLeft"
                style={{ textAnchor: 'middle', fontSize: 15, fill: '#666' }}
              />
            </YAxis>
            <Tooltip
              content={tooltipContent}
              formatter={(value, name) => (name === yAxisKey ? value : `${value}%`)}
              labelFormatter={labelFormatter}
            />
            <Bar dataKey={yAxisKey} fill="#8fa8f8" barSize={barSize}>
              {coloredData.map((entry, idx) => (
                <Cell key={`cell-${idx}`} fill={entry.color || '#8fa8f8'} />
              ))}
              <LabelList
                dataKey={yAxisKey}
                position="insideTop"
                content={({ x, y, width, height, value, index }) => {
                  const barColor = coloredData[index].color || '#8fa8f8';
                  if (height < 30) {
                    return (
                      <text x={x + width / 2} y={y - 28} textAnchor="middle" fontSize={12} fontWeight={600} fill={barColor}>
                        <tspan x={x + width / 2} dy={0} fontSize={15} fontWeight={600} fill={barColor}>{value}</tspan>
                        <tspan x={x + width / 2} dy={18} fontSize={14} fontWeight={400} fill={barColor}>({coloredData[index].percent}%)</tspan>
                      </text>
                    );
                  } else if (height < 50) {
                    return (
                      <text x={x + width / 2} y={y - 18} textAnchor="middle" fontSize={12} fontWeight={600} fill={barColor}>
                        <tspan x={x + width / 2} dy={0} fontSize={15} fontWeight={600} fill={barColor}>{value}</tspan>
                        <tspan x={x + width / 2} dy={18} fontSize={14} fontWeight={400} fill={barColor}>({coloredData[index].percent}%)</tspan>
                      </text>
                    );
                  }
                  return (
                    <text x={x + width / 2} y={y + 22} textAnchor="middle" fontSize={12} fontWeight={600} fill="#fff">
                      <tspan x={x + width / 2} dy={0} fontSize={15} fontWeight={600} fill="#fff">{value}</tspan>
                      <tspan x={x + width / 2} dy={18} fontSize={14} fontWeight={400} fill="#fff">({coloredData[index].percent}%)</tspan>
                    </text>
                  );
                }}
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default CommonBarChart;
