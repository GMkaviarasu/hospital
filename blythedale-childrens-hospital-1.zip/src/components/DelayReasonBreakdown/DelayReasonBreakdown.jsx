import React, { useEffect, useState } from 'react';
import axios from 'axios';
import CommonBarChart, { getBarTooltip } from '../common/CommonBarChart';
import styles from '../../styles/DelayReasonBreakdown.module.css';

const tooltipContent = getBarTooltip({
  titleFn: d => `Reason : ${d.reason}`,
  label1: 'Count',
  value1Fn: d => d.count,
  label2: 'Label',
  value2Fn: d => `${d.count} (${d.percent}%)`,
});

const DelayReasonBreakdown = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await axios.get('/api/Reason-delay-summary');
        if (Array.isArray(res.data)) {
          setData(res.data);
        } else {
          setData([]);
        }
      } catch (err) {
        setError('Failed to load data.');
        setData([]);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Dynamically generate yAxisTicks based on data
  const max = Math.max(...(Array.isArray(data) ? data.map(d => d.count) : [0]), 0);
  const step = 50;
  const yAxisTicks = Array.from({ length: Math.ceil(max / step) + 1 }, (_, i) => i * step);

  return (
    <div className={styles.container}>
      {loading ? (
        <div className="d-flex justify-content-center align-items-center" style={{ height: 200 }}>
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : error ? (
        <div style={{ color: '#b71c1c', background: '#fff3f3', padding: 16, borderRadius: 8, textAlign: 'center' }}>
          Sorry, we couldn't load your data right now. Please try again later.
        </div>
      ) : (
        <CommonBarChart
          data={Array.isArray(data) ? data : []}
          xAxisKey="reason"
          yAxisLabel="Number of Occurrences"
          title="Top 5 Delay Reasons with Summary"
          yAxisTicks={yAxisTicks}
          tooltipContent={tooltipContent}
        />
      )}
    </div>
  );
};

export default DelayReasonBreakdown; 