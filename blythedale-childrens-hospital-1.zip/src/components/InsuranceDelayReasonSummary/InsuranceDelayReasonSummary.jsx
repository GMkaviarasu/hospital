import React, { useState, useEffect } from 'react';
import CommonPieChart, { CommonPieLegend } from '../common/CommonPieChart';
import CommonBarChart from '../common/CommonBarChart';
import styles from '../../styles/InsuranceDelayReasonSummary.module.css';
import axios from 'axios';
import Select from 'react-select';

const TABS = [
  { label: 'Pie Chart', value: 'pie' },
  { label: 'Chart', value: 'chart' },
];

const InsuranceDelayReasonSummary = () => {
  const [activeTab, setActiveTab] = useState('pie');
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeIndex, setActiveIndex] = useState(null);
  const [selectedProvider, setSelectedProvider] = useState('');
  const [error, setError] = useState(false);

  // Get insurance providers from data (new JSON structure)
  const insuranceProviders = Array.isArray(data) ? data.map(d => d.insurance) : [];

  // Get selected provider's delay reasons for the bar chart
  const selectedProviderObj = Array.isArray(data) ? data.find(d => d.insurance === selectedProvider) || {} : {};
  let filteredBarData = selectedProviderObj && Array.isArray(selectedProviderObj.delayReasons) ? selectedProviderObj.delayReasons : [];

  // Calculate percent for each delay reason (for bar chart labels)
  if (Array.isArray(filteredBarData) && filteredBarData.length > 0) {
    const total = filteredBarData.reduce((sum, d) => sum + (d?.totalBills || 0), 0);
    filteredBarData = filteredBarData.map(d => ({
      ...d,
      percent: total ? ((d?.totalBills || 0) / total * 100).toFixed(1) : 0
    }));
  }

  // Dynamically generate yAxisTicks for bar chart (chart tab)
  const maxBar = Math.max(...(Array.isArray(filteredBarData) ? filteredBarData.map(d => d.totalBills) : [0]), 0);
  const stepBar = 50;
  const yAxisTicksBar = Array.from({ length: Math.ceil(maxBar / stepBar) + 1 }, (_, i) => i * stepBar);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(false);
      try {
        const response = await axios.get('/api/insurances/delays');
        if (response?.data && Array.isArray(response?.data) && response?.data?.length > 0) {
          setData(response?.data);
        } else {
          setData([]);
        }
      } catch (err) {
        setData([]);
        setError(true);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Set default selected provider when data loads or tab changes to 'chart'
  useEffect(() => {
    if (activeTab === 'chart' && insuranceProviders?.length > 0 && !selectedProvider) {
      setSelectedProvider(insuranceProviders[0]);
    }
  }, [activeTab, insuranceProviders, selectedProvider]);

  return (
    <div className={`${styles.outerContainer} ${styles.outerContainerRelative}`}>
      {/* Heading at the very top left with padding (only show on Pie Chart tab) */}
      {activeTab === 'pie' && (
        <div className={`${styles.title} ${styles.titlePadded}`}>Top 10 Insurance Providers</div>
      )}
      {/* Absolutely positioned tab buttons in the top right of the card */}
      <div className={styles.tabButtonBar}>
        {TABS.map(tab => (
          <button
            key={tab.value}
            onClick={() => setActiveTab(tab.value)}
            className={
              activeTab === tab.value
                ? `${styles.tabButton} ${styles.tabButtonActive}`
                : styles.tabButton
            }
          >
            {tab.label}
          </button>
        ))}
      </div>
      {/* Pie chart and legend side by side, centered, with horizontal scroll on small screens */}
      <div className={styles.chartScroll}>
        <div className={styles.chartRow}>
          <div className={`${styles.leftSection} ${styles.leftSectionNoPad}`}>
            {loading ? (
              <div style={{ minHeight: 120 }} className="d-flex justify-content-center align-items-center">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              </div>
            ) : error && (!data || data.length === 0) ? (
              <div style={{ color: '#b71c1c', background: '#fff3f3', padding: 16, borderRadius: 8, textAlign: 'center' }}>
                Sorry, we couldn't load your data right now. Please try again later.
              </div>
            ) : activeTab === 'pie' ? (
              <CommonPieChart
                data={data}
                dataKey="percent"
                nameKey="insurance"
                tooltipContent={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const d = payload[0].payload;
                    return (
                      <div className={styles.pieTooltipBox}>
                        {d.insurance} {d.percent}%
                      </div>
                    );
                  }
                  return null;
                }}
                activeIndex={activeIndex}
                setActiveIndex={setActiveIndex}
                renderLegend={(data, colors, activeIndex, setActiveIndex) => (
                  <div className={styles.legendGrid2Col}>
                    {CommonPieLegend(
                      data,
                      colors,
                      activeIndex,
                      setActiveIndex,
                      { labelField: 'insurance', valueField: 'percent', valueFormatter: v => v + '%' }
                    )}
                  </div>
                )}
              />
            ) : (
              <div className={styles.top5DelayReasonsSection}>
                {/* Heading above dropdown */}
                <div className={`${styles.title} ${activeTab === 'chart' ? styles.titleNoPadding : ''}`} style={{ marginBottom: 8 }}>
                  Top 5 Delay Reasons for {selectedProvider}
                </div>
                {/* Dropdown for insurance provider selection */}
                <div className={styles.providerDropdownRow}>
                  <label htmlFor="insurance-provider-select" className={styles.providerDropdownLabel}>
                    Select an insurance provider:
                  </label>
                  <div style={{ minWidth: 220 }}>
                    <Select
                      inputId="insurance-provider-select"
                      classNamePrefix="select"
                      options={insuranceProviders?.map(p => ({ value: p, label: p }))}
                      value={insuranceProviders?.map(p => ({ value: p, label: p }))?.find(opt => opt.value === selectedProvider) || null}
                      onChange={opt => setSelectedProvider(opt ? opt.value : '')}
                      placeholder="Select insurance provider..."
                      isSearchable
                      menuPortalTarget={document.body}
                      styles={{ menuPortal: base => ({ ...base, zIndex: 2000 }) }}
                    />
                  </div>
                </div>
                <CommonBarChart
                  data={Array.isArray(filteredBarData) ? filteredBarData : []}
                  xAxisKey="status"
                  yAxisKey="totalBills"
                  yAxisLabel="No of Bills"
                  title=""
                  yAxisTicks={yAxisTicksBar}
                  tooltipContent={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const d = payload[0].payload;
                      return (
                        <div className={styles.barTooltipBox}>
                          <div className={styles.barTooltipRow}>
                            <span className={styles.barTooltipLabel}>Primary Delay Reason :</span> <span className={styles.barTooltipValue}>{d.status}</span>
                          </div>
                          <div><span className={styles.barTooltipLabel}>Count :</span> <span className={styles.barTooltipValue}>{d.totalBills}</span></div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InsuranceDelayReasonSummary; 