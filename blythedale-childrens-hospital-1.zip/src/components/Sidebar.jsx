import React from 'react';
import styles from '../styles/Sidebar.module.css';
import { BiGridAlt } from 'react-icons/bi';

const Sidebar = () => {
  return (
    <div className={styles.sidebar}>
      {/* Logo/Icon */}
      <div className={styles.logoContainer}>
        <img
          src="/blythedale-childrens-hospital.png"
          alt="Blythedale Children's Hospital Logo"
          className={styles.logoImg}
        />
      </div>
      {/* Navigation */}
      <div className={styles.navWrapper}>
        <div className={styles.navItem}>
          <span className={styles.navIcon}>
            <BiGridAlt size={20} color="#7c3aed" />
          </span>
          Dashboard
        </div>
      </div>
    </div>
  );
};

export default Sidebar; 