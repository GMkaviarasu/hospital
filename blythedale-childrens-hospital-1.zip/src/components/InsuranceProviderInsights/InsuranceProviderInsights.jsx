import React, { useState, useEffect, useRef } from 'react';
import styles from '../../styles/InsuranceProviderInsights.module.css';
import Select from 'react-select';
import PrimeDataTable from '../common/PrimeDataTable';
import axios from 'axios';
import { FiDownload } from 'react-icons/fi';
import CommonPieChart, { CommonPieLegend } from '../common/CommonPieChart';

const tabOptions = [
  'All',
  '< 30 Days',
  '\u2265 30 Days',
  'Summary & Billing Payment Status',
];

const statusOptions = [
  { value: 'Posted', label: 'Posted' },
  { value: 'Reversed', label: 'Reversed' },
  { value: 'Cancelled', label: 'Cancelled' },
];

const InsuranceProviderInsights = () => {
  const [activeTab, setActiveTab] = useState(0);
  const [selectedStatuses, setSelectedStatuses] = useState([]);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const dataTableRef = useRef(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await axios.get('/api/insurances');
        if (response.data && Array.isArray(response.data)) {
          setData(response.data);
        } else {
          setData([]);
        }
      } catch (err) {
        setError('Failed to load data.');
        setData([]);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Tab filtering logic
  let pieData = Array.isArray(data) ? data : [];
  if (activeTab === 1) pieData = pieData.filter(row => row.days < 30);
  if (activeTab === 2) pieData = pieData.filter(row => row.days >= 30);

  const columns = [
    { field: 'insurance', header: 'Current Primary Insurance' },
    { field: 'status', header: 'Bill Status' },
    { field: 'totalBills', header: 'Total Bills' },
    { field: 'finalSum', header: 'Total Final Sum' },
    { field: 'denials', header: 'Total Denials' },
    { field: 'overPaidAdvance', header: 'Total Over Paid Advance' },
    { field: 'outstanding', header: 'Outstanding Amount' },
  ];

  // Custom tooltip: show only insurance name and percent on one line
  const pieTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const d = payload[0].payload;
      return (
        <div style={{ padding: 12, background: '#fff', borderRadius: 14, boxShadow: '0 2px 12px #0001', fontWeight: 600, fontSize: 15 }}>
          {d.insurance} {d.percent}%
        </div>
      );
    }
    return null;
  };

  return (
    <div className={styles.container}>
      <div className={styles.title}>Top 10 Providers</div>
      <div className={styles.tabBar}>
        {tabOptions.map((tab, idx) => (
          <button
            key={tab}
            className={activeTab === idx ? styles.activeTab : styles.tabBtn}
            onClick={() => setActiveTab(idx)}
            {...(activeTab === idx ? { className: styles.activeTab + ' ' + styles.tabBtnCustomFont } : { className: styles.tabBtn + ' ' + styles.tabBtnCustomFont })}
          >
            {tab}
          </button>
        ))}
      </div>
      {/* Only show filter/download in last tab */}
      {activeTab === 3 && (
        <div className={styles.filterBar + ' ' + styles.filterBarFlex}>
          <div className={styles.filterBarFlex} style={{ flex: 1 }}>
            <div className={styles.selectWrapper + ' ' + styles.selectMinMaxWidth}>
              <Select
                isMulti
                options={statusOptions}
                value={selectedStatuses}
                onChange={setSelectedStatuses}
                placeholder="+ Select Bill Status"
                classNamePrefix="select"
                menuPortalTarget={document.body}
                styles={{
                  menuPortal: base => ({ ...base, zIndex: 2000 }),
                  control: base => ({ ...base, minWidth: 320, maxWidth: 340, width: '100%' }),
                }}
              />
            </div>
            <button
              className={"btn btn-outline-primary btn-sm ms-2 " + styles.clearBtnNoWrap}
              onClick={() => setSelectedStatuses([])}
            >
              Clear filters
            </button>
          </div>
          <div style={{ marginLeft: 'auto' }}>
            <button
              className={styles.downloadBtn}
              onClick={() => dataTableRef.current && dataTableRef.current.exportCSV({ filename: 'InsuranceProvidersReport.csv' })}
            >
              <span>Download</span>
              <FiDownload className={styles.downloadIcon} />
            </button>
          </div>
        </div>
      )}
      <div className={styles.tableWrapper}>
        {loading ? (
          <div className={styles.loadingState}>
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : error && (!data || data.length === 0) ? (
          <div style={{ color: '#b71c1c', background: '#fff3f3', padding: 16, borderRadius: 8, textAlign: 'center' }}>
            Sorry, we couldn't load your data right now. Please try again later.
          </div>
        ) : (
          activeTab < 3 ? (
            pieData && pieData.length > 0 ? (
              <CommonPieChart
                data={pieData}
                dataKey="percent"
                nameKey="insurance"
                tooltipContent={pieTooltip}
                renderLegend={(data, colors, activeIndex, setActiveIndex) =>
                  CommonPieLegend(
                    data,
                    colors,
                    activeIndex,
                    setActiveIndex,
                    {
                      labelField: 'insurance',
                      valueField: 'percent',
                      valueFormatter: v => `${v}%`
                    }
                  )
                }
              />
            ) : (
              <div className={styles.emptyState}>No data available</div>
            )
          ) : (
            <PrimeDataTable
              ref={dataTableRef}
              columns={columns}
              data={
                selectedStatuses.length === 0
                  ? data
                  : data.filter(row => selectedStatuses.some(s => s.value === row.status))
              }
            />
          )
        )}
      </div>
    </div>
  );
};

export default InsuranceProviderInsights; 