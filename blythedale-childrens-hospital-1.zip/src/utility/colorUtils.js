// Utility to generate N visually distinct colors using HSL
export function generateColors(count) {
  const colors = [];
  for (let i = 0; i < count; i++) {
    const hue = Math.round((360 * i) / count);
    colors.push(`hsl(${hue}, 65%, 60%)`);
  }
  return colors;
}

// Utility to generate a light and strong color pair for a given index
export function getLightAndStrongColorByIndex(idx, total) {
  // Base hue for this index
  const hue = Math.round((360 * idx) / total);
  // Light color for background
  const light = `hsl(${hue}, 65%, 90%)`;
  // Strong color for value text (bolder)
  const strong = `hsl(${hue}, 80%, 35%)`;
  return { light, strong };
} 