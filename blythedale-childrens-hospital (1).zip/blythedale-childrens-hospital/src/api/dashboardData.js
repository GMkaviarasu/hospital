// src/data/dashboardData.js
const dashboardData = {
  taskSummary: {
    title: "Today's Actionable Task Summary",
    columns: [
      { field: "taskCategory", header: "Task Category", sortable: false },
      { field: "count", header: "Count", sortable: false },
      { field: "priority", header: "Priority", sortable: false },
      { field: "dueDate", header: "Due Date", sortable: false },
      { field: "denialReason", header: "Top Denial Reason", sortable: false }
    ],
    rows: [
      {
        taskCategory: "Appeals Due (Within 3 Days)",
        count: 9,
        priority: "High",
        dueDate: "07/20/2025",
        denialReason: "Review and resubmit with supporting documentation"
      },
      {
        taskCategory: "New Denials (Past 24 Hours)",
        count: 13,
        priority: "Medium",
        dueDate: "07/18/2025",
        denialReason: "Filter by Insurer and denial reason codes"
      },
      {
        taskCategory: "Pending Claims Awaiting Info",
        count: 7,
        priority: "Medium",
        dueDate: "07/19/2025",
        denialReason: "Missing insurance ID or physician treatment summary"
      },
      {
        taskCategory: "Overdue Follow-ups (>7 Days)",
        count: 5,
        priority: "High",
        dueDate: "07/17/2025",
        denialReason: "Claims marked inactive, needs reactivation or closure"
      },
      {
        taskCategory: "Claims Held Due to Doc Errors",
        count: 6,
        priority: "High",
        dueDate: "07/19/2025",
        denialReason: "Claims rejected for incomplete billing line details"
      }
    ]
  },
  accountsReceivable: {
    title: "Aging Accounts Receivable Summary",
    columns: [
      { field: "aging", header: "Aging", sortable: false },
      { field: "amount", header: "Amount ($)", sortable: false },
      { field: "claims", header: "Claims", sortable: false },
      { field: "priority", header: "Priority", sortable: false }
    ],
    rows: [
      { aging: "0–30 Days", amount: 28400, claims: 12, priority: "Low" },
      { aging: "31–60 Days", amount: 46000, claims: 19, priority: "Medium" },
      { aging: "61–90 Days", amount: 1000000, claims: 10, priority: "High" }
    ]
  },
  denials: {
    title: "Denial Alerts & Resolution Tracker",
    columns: [
      { field: "denialCode", header: "Denial Code", sortable: false },
      { field: "description", header: "Description", sortable: false },
      { field: "count", header: "Count", sortable: false },
      { field: "action", header: "Action", sortable: false }
    ],
    rows: [
      {
        denialCode: "CO-50",
        description: "Not medically necessary",
        count: 6,
        action: "Attach additional therapy notes"
      },
      {
        denialCode: "CO-18",
        description: "Duplicate Claim",
        count: 4,
        action: "Verify & Remove"
      },
      {
        denialCode: "CO-16",
        description: "Missing Information",
        count: 5,
        action: "Resubmit with modifier"
      }
    ]
  },
  insurerTracker: {
    title: "Insurer Issue Tracker",
    columns: [
      { field: "insurer", header: "Insurer", sortable: false },
      { field: "issue", header: "Recurring Issue", sortable: false },
      { field: "claims", header: "Affected Claims", sortable: false },
      { field: "trend", header: "Trend", sortable: false },
      { field: "recommendation", header: "Action Recommendation", sortable: false }
    ],
    rows: [
      {
        insurer: "MCD",
        issue: "Over-limit therapy denials",
        claims: 7,
        trend: "Rising",
        recommendation: "Submit frequency override request"
      },
      {
        insurer: "HFHSP",
        issue: "Missing authorization details",
        claims: 5,
        trend: "Rising",
        recommendation: "Match EMR and claim auth data"
      },
      {
        insurer: "Aetna",
        issue: "OT/ST claims missing modifiers",
        claims: 6,
        trend: "Stable",
        recommendation: "Re-train team on proper modifier usage"
      },
      {
        insurer: "EMPBCCON",
        issue: "Neuro PT marked as non-covered",
        claims: 4,
        trend: "Falling",
        recommendation: "Confirm coverage in benefits portal"
      },
      {
        insurer: "BENEXHAUST",
        issue: "NPI/taxonomy code mismatch",
        claims: 3,
        trend: "Rising",
        recommendation: "Correct taxonomy in claim profile"
      }
    ]
  },
  openClaims: {
    title: "Open Claims",
    columns: [
      { field: "accountNumber", header: "Account Number", sortable: false },
      { field: "documentNeeded", header: "Document Needed", sortable: false },
      { field: "assignedTo", header: "Assigned To", sortable: false },
      { field: "followUpDate", header: "Follow-up Date", sortable: false }
    ],
    rows: [
      {
        accountNumber: "V00000164385",
        documentNeeded: "Progress Notes (PT)",
        assignedTo: "Rehab Dept",
        followUpDate: "07/19/2025"
      },
      {
        accountNumber: "V00000162930",
        documentNeeded: "Pre-auth Form",
        assignedTo: "Front Desk",
        followUpDate: "07/20/2025"
      }
    ]
  },
  renewals: {
    title: "Upcoming Authorizations for Renewal",
    columns: [
      { field: "patientId", header: "Patient ID", sortable: false },
      { field: "name", header: "Name", sortable: false },
      { field: "service", header: "Service", sortable: false },
      { field: "expiryDate", header: "Expiry Date", sortable: false },
      { field: "status", header: "Status", sortable: false }
    ],
    rows: [
      {
        patientId: "EO-B2023103015438441",
        name: "Emily R.",
        service: "OT (Neuro)",
        expiryDate: "07/19/2025",
        status: "Not Initiated"
      },
      {
        patientId: "EO-B2023071514430872",
        name: "Noah M.",
        service: "Ortho",
        expiryDate: "07/20/2025",
        status: "Request in Draft"
      },
      {
        patientId: "EO-B2024071013000987",
        name: "Ava L.",
        service: "Occupational Therapy",
        expiryDate: "07/22/2025",
        status: "Awaiting documentation"
      }
    ]
  },
  paymentVariance: {
    title: "Payment Variance",
    columns: [
      { field: "claimId", header: "Claim ID", sortable: false },
      { field: "expected", header: "Expected ($)", sortable: false },
      { field: "paid", header: "Paid ($)", sortable: false },
      { field: "variance", header: "Variance ($)", sortable: false },
      { field: "status", header: "Status", sortable: false }
    ],
    rows: [
      {
        claimId: "CO-50",
        expected: 3900,
        paid: 2200,
        variance: 1700,
        status: "Pending Review"
      },
      {
        claimId: "CO-109",
        expected: 5300,
        paid: 2000,
        variance: 3300,
        status: "Appeal Required"
      },
      {
        claimId: "CO-16",
        expected: 2100,
        paid: 1800,
        variance: 300,
        status: "Correction Sent"
      }
    ]
  }
};

export default dashboardData;
