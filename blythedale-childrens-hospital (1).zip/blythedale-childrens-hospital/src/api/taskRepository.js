import axios from "axios";
import { API_BASE_URL } from "../utility/constants";

const getActionableTaskSummaryByAging = async (aging) => {
    try {
    //   const response = await axios.get(`${API_BASE_URL}/aging/details/STAMATI,MARIE/${encodeURIComponent(aging)}`);
    //   return response.data;

     const data =[
        {
          "AccountNumber": "V097502",
          "AccountType": "O DAY",
          "ActionRequired": "development",
          "BillNo": 396,
          "EntryBy": "STAMATI,MARIE",
          "Name": "ZUZZOLO,MARY",
          "PatientID": "E0-200000010496"
        },
        {
          "AccountNumber": "V0002",
          "AccountType": "O DAY",
          "ActionRequired": "development",
          "BillNo": 465,
          "EntryBy": "STAMATI,MARIE",
          "Name": "ZUZZOLO,MARY",
          "PatientID": "E0-20100010496"
        },
        {
          "AccountNumber": "V007502",
          "AccountType": "O DAY",
          "ActionRequired": "development",
          "BillNo": 479,
          "EntryBy": "GOMEZ,GENNY|HERNANDEZ,ALEXANDRA|ROMAO,MARYSELI|STAMATI,MARIE",
          "Name": "ZUZZOLO,MARY",
          "PatientID": "E0-2000010496"
        }
      ];
    return data;


    } catch (error) {
      console.error('Error fetching task summary by aging:', error);
      throw error; // or return a fallback value like `return null` or `return []`
    }
  };
  

export { getActionableTaskSummaryByAging };