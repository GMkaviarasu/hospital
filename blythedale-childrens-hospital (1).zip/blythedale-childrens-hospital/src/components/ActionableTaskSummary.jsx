/**
 * @file ActionableTaskSummary.jsx
 * @summary Actionable Task Summary component
 * @description This component displays the actionable task summary for the day
 * @author 
 * @since Jan 15, 2025
 */
import React, { useEffect, useState } from 'react'
import PrimeDataTable from './common/PrimeDataTable';
import { getActionableTaskSummaryByAging } from '../api/taskRepository';
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import TableContainer from './common/TableContainer';

/**
 * @function ActionableTaskSummary
 * @description This component displays the actionable task summary for the day
 * @returns {JSX.Element} The ActionableTaskSummary component
 */
function ActionableTaskSummary() {
    const [actionableTasks, setActionableTasks] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const location = useLocation();
    const aging = location.state?.aging;
    console.log("aging", aging)

    /**
    * @function fetchData
    * @description This function fetches the actionable task summary for the day
    * @returns {Promise<void>} The Promise that resolves to the actionable task summary
    */
    const fetchData = async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await getActionableTaskSummaryByAging(aging);
            setActionableTasks(data);
        } catch (err) {
            setError('Failed to load actionable tasks.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    // Define columns for the PrimeDataTable
    const columns = [
        { field: 'AccountNumber', header: 'Account ID', sortable: false },
        { field: 'BillNo', header: 'Claim ID', sortable: false },
        { field: 'Service Type', header: 'Service Type', sortable: false },
        { field: 'Appeal Type', header: 'Appeal Type', sortable: false },
        { field: 'EntryBy', header: 'Owner', sortable: false },
        { field: 'Due Date', header: 'Due Date', sortable: false },
        { field: 'Action Required', header: 'Action Required', sortable: false },
    ];

    return (
        <div className='main'>
            <div className='content'>
                <div className="container py-4">
                    <h2 className="mb-4 fw-bold">Billing Navigator</h2>
                    <TableContainer title={"Today's Actionable Task Summary"}>
                        <PrimeDataTable columns={columns} data={actionableTasks} loading={loading} error={error} pagination={false} />
                        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 32 }}>
                            <button
                                style={{
                                    background: '#7c3aed',
                                    color: '#fff',
                                    border: 'none',
                                    borderRadius: 12,
                                    padding: '10px 36px',
                                    fontWeight: 600,
                                    fontSize: '1rem',
                                    boxShadow: '0 2px 8px rgba(124,58,237,0.10)',
                                    cursor: 'pointer',
                                    transition: 'background 0.2s',
                                    outline: 'none',
                                }}
                                onClick={() => navigate('/')}
                            >
                                Back
                            </button>
                        </div>
                    </TableContainer>
                </div>
            </div>
        </div>
    )
}

export default ActionableTaskSummary