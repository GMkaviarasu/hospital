import React from "react";

const TableContainer = ({ title, children }) => {
  return (
    <div className="table-container border border-1 rounded mb-3 shadow-sm">
      {title && <div className="table-container-header p-3 fw-bold">{title}</div>}
      <div className="table-container-body p-3">{children}</div>
    </div>
  );
};

export default TableContainer;