"use client";
import "./chunk-DC5AMYBS.js";

// node_modules/primereact/column/column.esm.js
var Column = function Column2() {
};
Column.displayName = "Column";
export {
  Column
};
//# sourceMappingURL=primereact_column.js.map
