import {
  require_react
} from "./chunk-6GAV2S6I.js";
import "./chunk-DC5AMYBS.js";
export default require_react();
//# sourceMappingURL=react.js.map
