import axios from "axios";

const getAgingAccountSummary = async () => {
    try {
        const API_URL = `${import.meta.env.VITE_API_BASE_URL}/aging/details/STAMATI,MARIE`;
        const response = await axios.get(API_URL); 
        return response.data;
    } catch (error) {
        console.error('Error fetching task summary by aging:', error);
        throw error;
    }
};

const getDenialAlertData = async () => {
    try {
        const API_URL = `${import.meta.env.VITE_API_BASE_URL}/denial/alerts/details/STAMATI,MARIE`;
        const response = await axios.get(API_URL); 
        return response.data;
    } catch (error) {
        console.error('Error fetching denial alert data:', error);
        throw error;
    }
};

export { getAgingAccountSummary, getDenialAlertData };
