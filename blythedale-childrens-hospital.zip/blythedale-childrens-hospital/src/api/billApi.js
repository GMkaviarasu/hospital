import axios from "axios";

export const getBillDetails = async (AccountNumber, BillNo) => {
    const API_URL = `${import.meta.env.VITE_API_BASE_URL}/bill/details/${AccountNumber}/${BillNo}`;   
    try {
      const response = await axios.get(API_URL);
      return response;
    } catch (error) {
      console.error("Error fetching bill details:", error);
      throw error;
    }
  };
