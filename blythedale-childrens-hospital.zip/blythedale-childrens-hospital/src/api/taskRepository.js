import axios from "axios";

const fetchActionableTaskSummary = async (param, path) => {
  try {
    const API_URL = `${import.meta.env.VITE_API_BASE_URL}/${path}/details/STAMATI,MARIE/${param}`;
    const response = await axios.get(API_URL);
    return response.data;
  } catch (error) {
    console.error('Error fetching task summary by aging:', error);
    throw error;
  }
};

export { fetchActionableTaskSummary };
