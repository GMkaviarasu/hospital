/**
 * @file App.jsx
 * @summary Main application component for Blythedale Children's Hospital website
 * @description Root component that renders the complete hospital website with all sections and components
 * @author Sundar K
 * @since Jan 15, 2025
 */

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from "./components/Dashboard"
import ChatbotFloat from './components/common/ChatbotFloatButton.jsx';
import Sidebar from "./components/common/Sidebar.jsx";
import Topbar from "./components/common/Topbar.jsx";
import ActionableTaskSummary from "./components/ActionableTaskSummary.jsx";
import Account from './pages/Account.jsx';
import TaskList from './pages/TaskList.jsx';

/**
 * Main application component that renders the complete hospital website
 *
 * @function App
 * @returns {JSX.Element} The complete application layout
 */
function App() {
  return (
    <BrowserRouter>
      <div>
        <Sidebar />
        <Topbar />
        <div className='main-content-container'>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            {/* <Route path="/tasks" element={<ActionableTaskSummary />} /> */}
            <Route path="/tasks" element={<TaskList />} />
            <Route path="/accounts" element={<Account />} />
            {/* Add more routes here as needed */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </div>
      <ChatbotFloat />
    </BrowserRouter>
  )
}

export default App