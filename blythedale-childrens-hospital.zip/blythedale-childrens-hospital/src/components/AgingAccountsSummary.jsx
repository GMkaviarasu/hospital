import { useState, useEffect } from "react";
import axios from "axios";
import PrimeDataTable from "./common/PrimeDataTable";
import { useNavigate } from 'react-router-dom';

const AgingAccountsSummary = (props) => {

  const [agingDatas, setAgingDatas] = useState([]);
  const navigate = useNavigate();

  /**
  * @function fetchData
  * @description This function fetches the actionable task summary for the day
  * @returns {Promise<void>} The Promise that resolves to the actionable task summary
  */
  const fetchData = async () => {
    const API_URL = import.meta.env.VITE_USE_JSON_DB === 'false'
                    ? `${import.meta.env.VITE_API_BASE_URL}/aging/details/STAMATI,MARIE`
                    : `${import.meta.env.VITE_JSON_SERVER_BASE_URL}/aging`;
    const response = await axios.get(API_URL);
    // const data = await response.json();
    console.log("response", response.data);  
    setAgingDatas(response.data);
  };

  const modifiedColumns = props.columns.map((col) => {
    if (col.field === 'Claims') {
      return {
        ...col,
        body: (rowData) => (
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              navigate('/tasks', { state: { aging: rowData.Aging } });
            }}
            style={{ color: '#007bff', textDecoration: 'underline', cursor: 'pointer',  whiteSpace: 'normal', wordBreak: 'break-word' }}
          >
            {rowData.Claims}
          </a>
        )
      };
    }
    return col;
  });  
  useEffect(() => {
    
    fetchData();
  }, []);
  return (
    <PrimeDataTable columns={modifiedColumns} data={agingDatas} pagination={false} />
  );

};

export default AgingAccountsSummary;
