import React from 'react';
import './Stepper.css';

const steps = [
  'Claim Initiated',
  'Documentation',
  'Under Review',
  'Assessment',
  'Approval',
  'Settlement'
];

const Stepper = ({ currentStep = 0, AccountNumber}) => {
  return (
    <div className="d-flex align-items-center rounded stepper-container mb-3">
      {/* Account ID Box */}
      <div className="account-id-box bg-purple text-white rounded px-3 py-2 me-3">
        <div><small>Account ID</small></div>
        <div><small>{AccountNumber}</small></div>
      </div>

      {/* Steps */}
      <div className="flex-grow-1 d-flex align-items-center justify-content-between">
        {steps.map((step, index) => (
          <div className="stepper-step text-center" key={index}>
            <div
              className={`step-circle mx-auto ${
                index <= currentStep ? 'active' : ''
              }`}
            />
            <div
              className={`step-label mt-1 ${
                index === currentStep ? 'text-purple fw-bold' : ''
              }`}
            >
              {step}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Stepper;
