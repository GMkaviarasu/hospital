/**
 * @file Dashboard.jsx
 * @summary Dashboard component for Blythedale Children's Hospital
 * @description This component displays the dashboard for the Blythedale Children's Hospital
 * @author Sundar K
 * @since Jan 15, 2025
 */
import React from 'react'
import "./Dashboard.css";
import TableContainer from './common/TableContainer';
import dashboardData from '../api/dashboardData';
import PrimeDataTable from './common/PrimeDataTable';
import AgingAccountsSummary from './AgingAccountsSummary';
import DenialAlert from './dashboard/DenialAlert';
/**
 * Dashboard component that displays the welcome message for Blythedale Children's Hospital
 *
 * @function Dashboard
 * @returns {JSX.Element} The dashboard component
 */
function Dashboard() {
  const {
    taskSummary,
    accountsReceivable,
    denials,
    insurerTracker,
    openClaims,
    renewals,
    paymentVariance
  } = dashboardData;

  

  return (
    <div className="main">
      <div className="content">
        <div className="container py-4">
          <h2 className="mb-4 fw-bold">Billing Navigator</h2>
          <div className="row">
            {/* Left Column - 8 columns */}
            <div className="col-md-7">
              <TableContainer title={taskSummary.title}>
                <PrimeDataTable columns={taskSummary.columns} data={taskSummary.rows} pagination={false} />
              </TableContainer>
              <TableContainer title={insurerTracker.title}>
                <PrimeDataTable columns={insurerTracker.columns} data={insurerTracker.rows} pagination={false} />
              </TableContainer>
              <TableContainer title={renewals.title}>
                <PrimeDataTable columns={renewals.columns} data={renewals.rows} pagination={false} />
              </TableContainer>
            </div>

            {/* Right Column - 4 columns */}
            <div className="col-md-5">
              <TableContainer title={accountsReceivable.title}>
                <AgingAccountsSummary columns={accountsReceivable.columns} />
                {/* <PrimeDataTable columns={modifiedColumns} data={accountsReceivable.rows} pagination={false} /> */}
              </TableContainer>
              <TableContainer title={denials.title}>
                <DenialAlert columns={denials.columns} />
              </TableContainer>
              <TableContainer title={openClaims.title}>
                <PrimeDataTable columns={openClaims.columns} data={openClaims.rows} pagination={false} />
              </TableContainer>
              <TableContainer title={paymentVariance.title}>
                <PrimeDataTable columns={paymentVariance.columns} data={paymentVariance.rows} pagination={false} />
              </TableContainer>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}

export default Dashboard