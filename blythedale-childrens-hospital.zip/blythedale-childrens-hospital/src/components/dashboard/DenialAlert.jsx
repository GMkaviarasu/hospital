import { useState, useEffect } from "react";
import axios from "axios";
import PrimeDataTable from "../common/PrimeDataTable";
import { useNavigate } from 'react-router-dom';
import { getDenialAlertData } from "../../api/agingRepository";


const DenialAlert = (props) => {

  const [agingDatas, setAgingDatas] = useState([]);
  const navigate = useNavigate();

  /**
  * @function fetchData
  * @description This function fetches the actionable task summary for the day
  * @returns {Promise<void>} The Promise that resolves to the actionable task summary
  */
  const fetchData = async () => {
    const data = await getDenialAlertData();
    setAgingDatas(data);
  };

  const modifiedColumns = props.columns.map((col) => {
    if (col.field === 'count') {
      return {
        ...col,
        body: (rowData) => (
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              navigate('/tasks', { state: { DenialCode: rowData.DenialCode, url:'denial/alerts' } });
            }}
            style={{ color: '#007bff', textDecoration: 'underline', cursor: 'pointer',  whiteSpace: 'normal', wordBreak: 'break-word' }}
          >
            {rowData.count}
          </a>
        )
      };
    }
    return col;
  }); 
  useEffect(() => {    
    fetchData();
  }, []);
  return (
    <PrimeDataTable columns={modifiedColumns} data={agingDatas} pagination={false} />
  );

};

export default DenialAlert;
