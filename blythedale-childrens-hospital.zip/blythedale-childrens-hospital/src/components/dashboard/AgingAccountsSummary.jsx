import { useState, useEffect } from "react";
import axios from "axios";
import PrimeDataTable from "./common/PrimeDataTable";
import { useNavigate } from 'react-router-dom';
import { getAgingAccountSummary } from '../api/agingRepository';


const AgingAccountsSummary = (props) => {

  const [agingDatas, setAgingDatas] = useState([]);
  const navigate = useNavigate();

  /**
  * @function fetchData
  * @description This function fetches the actionable task summary for the day
  * @returns {Promise<void>} The Promise that resolves to the actionable task summary
  */
  const fetchData = async () => {
    const data = await getAgingAccountSummary();   
    // const data = await response.json();
    setAgingDatas(data);
  };

  const modifiedColumns = props.columns.map((col) => {
    if (col.field === 'Claims') {
      return {
        ...col,
        body: (rowData) => (
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              navigate('/tasks', { state: { aging: rowData.Aging, url:'aging', page:'aging' } });
            }}
            style={{ color: '#007bff', textDecoration: 'underline', cursor: 'pointer',  whiteSpace: 'normal', wordBreak: 'break-word' }}
          >
            {rowData.Claims}
          </a>
        )
      };
    }
    return col;
  });  
  useEffect(() => {
    
    fetchData();
  }, []);
  return (
    <PrimeDataTable columns={modifiedColumns} data={agingDatas} pagination={false} />
  );

};

export default AgingAccountsSummary;
