import React from "react";
import "./Topbar.css";

const Topbar = () => {
  return (
    <div className="topbar">
      <div className="angled-box">
        <img
          src="/blythedale-childrens-hospital.png"
          alt="Logo"
        />
      </div>
      <div className="user-info">
        <span>
          STAMATI,MARIE <b>(Biller)</b>
        </span>
        <img src="https://i.pravatar.cc/150?img=32" alt="Profile" />
      </div>
      <div className="top-bar-spacer"></div>
    </div>
  );
};

export default Topbar;
