import React from "react";
import "./TableContainer2.css";

const TableContainer = ({ tableContainerHeader, children }) => {
    return (
      <div className="table-container">
        <div className="table-container-header">
          <h5>{tableContainerHeader}</h5>
        </div>
        <div className="table-container-body">
          {children}
        </div>
      </div>
    );
  };

export default TableContainer;
